# _*_coding:utf-8_*_
from keras.layers import *
import jieba
import multiprocessing
import pandas as pd
from gensim.models import Word2Vec
import numpy as np
import keras.backend as K
from keras.callbacks import Callback, ModelCheckpoint
from keras.models import Model
from keras.utils.np_utils import to_categorical
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import classification_report, accuracy_score, f1_score
import ipykernel
def token(text):
#jieba实现分词
  return " ".join(jieba.cut(text))
#文本列表和词向量输出路径
def train_w2v(text_list=None, output_vector='data/w2v.txt'):
#训练w2v词汇
    print("training..")
    corpus = [text.split() for text in text_list]
    model = Word2Vec(corpus, size=100, window=5, min_count=1, workers=multiprocessing.cpu_count())
    # 保存词向量为vector文件
    model.wv.save_word2vec_format(output_vector, binary=False)
#输入给定的训练集train.csv,测试机test.csv,提交样例sample.csv
train = pd.read_csv('data/train.csv', sep='\t')
test = pd.read_csv('data/test_new.csv')
sub = pd.read_csv('data/sample.csv')
#训练当前需要的全部数据。
train['id'] = [i for i in range(len(train))]
test['label'] = [-1 for i in range(len(test))]
df = pd.concat([train, test], sort=False)
df['token_text'] = df['comment'].apply(lambda x: token(x))
texts = df['token_text'].values.tolist()
# 构建词汇表,Tokenizer是一个用于向量化文本，或将文本转换为序列的类。是用来文本预处理的第一步：分词。
#使用tokenzier将要训练的文本数字化,拆分更新tokenizer词典
#tokenzier过滤低频词，比如按出现频率
tokenizer = Tokenizer()
tokenizer.fit_on_texts(texts)
#以词典与文本中索引匹配
word_index = tokenizer.word_index
print("词语数：{}".format(len(word_index)))
# 数据规定长度
EMBEDDING_DIM = 100
MAX_SEQUENCE_LENGTH = 100
sequences = tokenizer.texts_to_sequences(texts)
data = pad_sequences(sequences, maxlen=MAX_SEQUENCE_LENGTH)
# 对测试集,训练集内容类别编码
x_train = data[:len(train)]
x_test = data[len(train):]
y_train = to_categorical(train['label'].values)
y_train = y_train.astype(np.int32)
print(y_train)
# 预训练 创建embedding_layer,将一个词映射成为固定维度的稠密向量
# 构造矩阵, 实现神经网络的前向传播.
def build_embeddings_index(word_index, w2v_file):
#word_index: 词语索引字典
#w2v_file: 词向量文件
# 词向量为文本格式
    embedding_index = {}
    f = open(w2v_file, 'r', encoding='utf-8')
    next(f)
#从文件中解析出每个词和它所对应的词向量，并用字典的方式存储
    for line in f:
        values = line.split()
        word = values[0]
        coefs = np.asarray(values[1:], dtype='float32')
        embedding_index[word] = coefs
    f.close()
#构造矩阵,实现神经网络向前传播
#embeddings_matrix：嵌入矩阵，用于Embedding的初始化,根据字典构建词向量矩阵
    embedding_matrix = np.random.random(size=(len(word_index)+1, EMBEDDING_DIM))
    for word, i in word_index.items():
        #预训练索引嵌入
        embedding_vector = embedding_index.get(word)
        if embedding_vector is not None:
            embedding_matrix[i] = embedding_vector
#使用embedding layer来学习词嵌入, 将一个词映射成为固定维度的稠密向量
#根据得到的字典生成上文所定义的词向量矩阵
    embedding_layer = Embedding(len(word_index) + 1,EMBEDDING_DIM, weights=[embedding_matrix],input_length=MAX_SEQUENCE_LENGTH, trainable=True)
    return embedding_layer
#rcnn循环卷积神经网络模型
def create_rcnn():
    input_current = Input((MAX_SEQUENCE_LENGTH,))
    input_left = Input((MAX_SEQUENCE_LENGTH,))
    input_right = Input((MAX_SEQUENCE_LENGTH,))
#嵌入层各项参数导入
    embedding_layer = build_embeddings_index(word_index, 'data/w2v.txt')
    embedding_current = embedding_layer(input_current)
    embedding_left = embedding_layer(input_left)
    embedding_right = embedding_layer(input_right)
#循环神经网络模型构建,利用keras进行情感分析
    x_left = SimpleRNN(128, return_sequences=True)(embedding_left)
    x_right = SimpleRNN(128, return_sequences=True, go_backwards=True)(embedding_right)
    x_right = Lambda(lambda x: K.reverse(x, axes=1))(x_right)
    x = Concatenate(axis=2)([x_left, embedding_current, x_right])
#使用激励函数tanh
    x = Conv1D(64, kernel_size=1, activation='tanh')(x)
    x = GlobalMaxPooling1D()(x)
    # 使用softmax激活函数指定维数进行多分类
    output = Dense(2, activation='softmax')(x)
    #创建输入输出模型
    model = Model(inputs=[input_current, input_left, input_right], outputs=output)
    return model

train_pred = np.zeros((len(train), 2))
test_pred = np.zeros((len(test), 2))
#按折叠次数为5,shuffle=Ture使用随机种子进行交叉验证
skf = StratifiedKFold(n_splits=5, random_state=52, shuffle=True)
for i, (train_index, valid_index) in enumerate(skf.split(x_train, train['label'])):
    print("n@:{}fold".format(i + 1))
    #按索引获取数据
    X_train = x_train[train_index]
    #通过valid验证集
    X_valid = x_train[valid_index]
    y_tr = y_train[train_index]
    y_val = y_train[valid_index]
#loss损失函数网络衡量在训练数据上的性能，即网络如何朝着正确的方向前进。 优化器rmsprop,监控指标acc
#输出模型参数
    model = create_rcnn()
    model.compile(loss='categorical_crossentropy',optimizer='rmsprop',metrics=['acc'])
    model.summary()
#检查点,利用keras中的回调函数ModelCheckpoint进行保存。
    #显示保存记录并保留最好的记录
    checkpoint = ModelCheckpoint(filepath='models/rcnn_text_{}.h5'.format(i + 1),monitor='val_loss',verbose=1, save_best_only=True)
    #以validationdata为参数验证迭代10次,更新批量大小为32
    history = model.fit(X_train, y_tr,validation_data=(X_valid, y_val),epochs=10, batch_size=32,callbacks=[checkpoint])
#输出预测结果
    train_pred[valid_index, :] = model.predict(X_valid)
    test_pred += model.predict(x_test)
# 训练数据预测结果,按照索引大小
labels = np.argmax(test_pred, axis=1)
sub['label'] = labels
sub.to_csv('result/rcnnv.csv', index=None)
oof_df = pd.DataFrame(train_pred)
#合并
train = pd.concat([train, oof_df], axis=1)
labels = np.argmax(train_pred, axis=1)
train['pred'] = labels
#将训练报告分类
train.to_excel('result/rcnnv_train.xlsx', index=None)
print(classification_report(train['label'].values, train['pred'].values))
print(f1_score(train['label'].values, train['pred'].values))
